# openxml-validator

Supports DOCX (--docx) default, XLSX (--xlsx), PPTX (--pptx) modes.

Building:
```bash
openxml-validator$ dotnet build --configuration=Release
Restore complete (0.3s)
  Program net10.0 succeeded (0.2s) → bin/Release/net10.0/Program.dll

Build succeeded in 0.7s
```

Running:
```bash
openxml-validator$ dotnet bin/Release/net10.0/Program.dll --docx ../unioffice-src/document/testdata/golden/activex.docx
Processing DOCX File: ../unioffice-src/document/testdata/golden/activex.docx
Document is valid
```

```bash
$ dotnet bin/Release/net10.0/Program.dll --pptx ../unioffice-src/presentation/testdata/golden/chart_saved.pptx
Processing PPTX File: ../unioffice-src/presentation/testdata/golden/chart_saved.pptx
Document is not valid

Error description: The element has unexpected child element 'http://schemas.openxmlformats.org/drawingml/2006/chart:ext'.
Content type of part with error: application/vnd.openxmlformats-officedocument.drawingml.chart+xml
Location of error: /c:chartSpace[1]/c:chart[1]/c:extLst[1]
```
